<?php
/**
 * Memproses pendaftaran akun pelanggan, memvalidasi data yang dikirim, dan menyimpan akun baru ke database.
 */
session_start();
include "config/koneksi.php";

$message = "";
$messageType = "";

if (isset($_POST['register'])) {
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $no_hp    = mysqli_real_escape_string($conn, $_POST['no_hp']);
    $alamat   = mysqli_real_escape_string($conn, $_POST['alamat']);

    // Cek ketersediaan username / email
    $cek = mysqli_query($conn, "SELECT * FROM user WHERE username='$username' OR email='$email'");

    if (mysqli_num_rows($cek) > 0) {
        $message = "Username atau email sudah terdaftar!";
        $messageType = "danger";
    } else {
        // Enkripsi password
        $password_hashed = password_hash($password, PASSWORD_DEFAULT);
        
        // Simpan user baru beserta no_hp dan alamat (default role 'user')
        $insert = mysqli_query($conn, "INSERT INTO user (nama, username, email, password, no_hp, alamat, role) VALUES ('$nama', '$username', '$email', '$password_hashed', '$no_hp', '$alamat', 'user')");

        if ($insert) {
            $message = "Pendaftaran berhasil! Silakan login.";
            $messageType = "success";
        } else {
            $message = "Gagal mendaftar, terjadi kesalahan sistem.";
            $messageType = "danger";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - NEO BSTORE</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #FFFFFF;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            padding: 40px 0;
        }

        .top-logo {
            position: absolute;
            top: 30px;
            left: 40px;
        }

        .logo-text {
            font-weight: 800;
            font-size: 22px;
            color: #000000;
            margin: 0;
        }

        .logo-text span {
            color: #3B82F6;
        }

        .auth-container {
            width: 100%;
            max-width: 420px;
            padding: 20px;
        }

        .auth-title {
            font-weight: 700;
            font-size: 20px;
            color: #0F172A;
            letter-spacing: 0.5px;
        }

        .custom-input-group {
            border: 1px solid #CBD5E1;
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.2s ease;
            background-color: #FFFFFF;
        }

        .custom-input-group:focus-within {
            border-color: #3B82F6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
        }

        .custom-input-group .input-group-text {
            border: none;
            background: transparent;
            color: #64748B;
        }

        .custom-input-group .form-control {
            border: none;
            box-shadow: none;
            font-size: 13px;
            padding: 10px 12px 10px 0;
            font-weight: 500;
        }

        .custom-input-group .form-control::placeholder {
            color: #94A3B8;
            letter-spacing: 0.5px;
        }

        .btn-auth {
            background-color: #3B82F6;
            color: #FFFFFF;
            font-weight: 700;
            font-size: 14px;
            border-radius: 10px;
            padding: 10px;
            border: none;
            letter-spacing: 0.5px;
            transition: all 0.2s ease;
        }

        .btn-auth:hover {
            background-color: #2563EB;
            color: #FFFFFF;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        @media (max-width: 576px) {
            .top-logo {
                position: static;
                text-align: center;
                margin-bottom: 20px;
            }
            body {
                flex-direction: column;
                justify-content: flex-start;
                padding-top: 20px;
            }
        }
    </style>
</head>

<body>

    <div class="top-logo">
        <h3 class="logo-text">NEO <span>BSTORE</span></h3>
    </div>

    <div class="auth-container">
        
        <h4 class="auth-title text-center mb-4">REGISTER</h4>

        <?php if (!empty($message)): ?>
            <div class="alert alert-<?= $messageType; ?> alert-dismissible fade show small p-2 mb-3" role="alert">
                <?= $message; ?>
                <button type="button" class="btn-close p-2" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            
            <!-- Input Nama -->
            <div class="input-group custom-input-group mb-3">
                <span class="input-group-text ps-3">
                    <i class="bi bi-person"></i>
                </span>
                <input type="text" name="nama" class="form-control" placeholder="NAMA LENGKAP" required autocomplete="off" value="<?= isset($_POST['nama']) ? htmlspecialchars($_POST['nama']) : ''; ?>">
            </div>

            <!-- Input Email -->
            <div class="input-group custom-input-group mb-3">
                <span class="input-group-text ps-3">
                    <i class="bi bi-envelope"></i>
                </span>
                <input type="email" name="email" class="form-control" placeholder="EMAIL" required autocomplete="off" value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>

            <!-- Input No HP / WhatsApp -->
            <div class="input-group custom-input-group mb-3">
                <span class="input-group-text ps-3">
                    <i class="bi bi-whatsapp"></i>
                </span>
                <input type="text" name="no_hp" class="form-control" placeholder="NOMOR HP / WHATSAPP" required autocomplete="off" value="<?= isset($_POST['no_hp']) ? htmlspecialchars($_POST['no_hp']) : ''; ?>">
            </div>

            <!-- Input Alamat Lengkap -->
            <div class="input-group custom-input-group mb-3">
                <span class="input-group-text ps-3 align-items-start pt-2">
                    <i class="bi bi-geo-alt"></i>
                </span>
                <textarea name="alamat" class="form-control" rows="2" placeholder="ALAMAT LENGKAP PENGIRIMAN" required style="resize: none;"><?= isset($_POST['alamat']) ? htmlspecialchars($_POST['alamat']) : ''; ?></textarea>
            </div>

            <!-- Input Username -->
            <div class="input-group custom-input-group mb-3">
                <span class="input-group-text ps-3">
                    <i class="bi bi-at"></i>
                </span>
                <input type="text" name="username" class="form-control" placeholder="USERNAME" required autocomplete="off" value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
            </div>

            <!-- Input Password -->
            <div class="input-group custom-input-group mb-4">
                <span class="input-group-text ps-3">
                    <i class="bi bi-lock"></i>
                </span>
                <input type="password" id="password" name="password" class="form-control" placeholder="PASSWORD" required>
                <span class="input-group-text pe-3" style="cursor: pointer;" onclick="togglePassword()">
                    <i class="bi bi-eye" id="toggleIcon"></i>
                </span>
            </div>

            <!-- Submit Button -->
            <button type="submit" name="register" class="btn btn-auth w-100 mb-3">DAFTAR</button>

            <!-- Login Redirect -->
            <div class="text-center small text-secondary mt-3">
                Sudah punya akun? <a href="login.php" class="text-primary text-decoration-none fw-semibold">Login di sini</a>
            </div>

        </form>

    </div>

    <script>
        // Mengubah visibilitas kolom kata sandi antara teks terlihat dan tersembunyi.
        function togglePassword() {
            const passInput = document.getElementById('password');
            const toggleIcon = document.getElementById('toggleIcon');
            
            if (passInput.type === 'password') {
                passInput.type = 'text';
                toggleIcon.classList.replace('bi-eye', 'bi-eye-slash');
            } else {
                passInput.type = 'password';
                toggleIcon.classList.replace('bi-eye-slash', 'bi-eye');
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>