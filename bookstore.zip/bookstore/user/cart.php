<?php
/**
 * Menampilkan isi keranjang serta memproses perubahan jumlah, pemilihan item, dan perhitungan total belanja.
 */
session_start(); 
include __DIR__ . "/../config/koneksi.php";

$loggedIn = isset($_SESSION['id_user']); 

// Tangkap proses update jumlah via POST
if ($loggedIn && isset($_POST['update_jumlah'])) {
    $id_user = $_SESSION['id_user'];
    $id_cart = intval($_POST['id_cart']);
    $jumlah = intval($_POST['jumlah']);

    if ($jumlah < 1) { $jumlah = 1; }

    // Ambil stok maksimal dari database
    $q_stok = mysqli_query($conn, "
        SELECT buku.stok 
        FROM cart 
        JOIN buku ON cart.id_buku = buku.id_buku 
        WHERE cart.id_cart = '$id_cart' AND cart.id_user = '$id_user'
    ");
    $data_stok = mysqli_fetch_assoc($q_stok);

    if ($data_stok) {
        if ($jumlah > $data_stok['stok']) {
            $jumlah = $data_stok['stok'];
        }
        mysqli_query($conn, "UPDATE cart SET jumlah = '$jumlah' WHERE id_cart = '$id_cart' AND id_user = '$id_user'");
    }
    
    header("Location: cart.php");
    exit;
}

$cart = false;
$id_user = isset($_SESSION['id_user']) ? $_SESSION['id_user'] : 0;
if ($loggedIn) {
    $cart = mysqli_query($conn, "SELECT cart.*, buku.judul, buku.gambar, buku.harga, buku.stok FROM cart JOIN buku ON cart.id_buku=buku.id_buku WHERE cart.id_user='$id_user'");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Keranjang Belanja - NEO BSTORE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .qty-btn {
            border: none;
            background: none;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            padding: 0 8px;
            transition: color 0.2s;
        }
        .qty-btn.minus { color: #dc3545; }
        .qty-btn.plus { color: #198754; }
        .qty-btn:hover { opacity: 0.7; }
    </style>
</head>
<body>
    <div class="d-flex min-vh-100">
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
            </div>
            <nav class="sidebar-nav">
                <a href="../index.php"><i class="bi bi-house-door-fill"></i><span>Beranda</span></a>
                <a href="kategori.php"><i class="bi bi-bar-chart-steps"></i><span>Kategori</span></a>
                <a href="cart.php" class="active"><i class="bi bi-cart3"></i><span>Keranjang</span></a>
                <a href="pesanan.php"><i class="bi bi-box-seam"></i><span>Pesanan Saya</span></a>
                <a href="about.php"><i class="bi bi-info-circle"></i><span>Tentang Kami</span></a>
                <a href="contact.php"><i class="bi bi-chat-dots"></i><span>Hubungi Admin</span></a>
                <?php if ($loggedIn): ?>
                    <a href="../logout.php" class="text-danger mt-auto"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a>
                <?php else: ?>
                    <a href="../login.php" class="text-primary mt-auto"><i class="bi bi-box-arrow-in-right"></i><span>Login / Daftar</span></a>
                <?php endif; ?>
            </nav>
        </aside>

        <main class="content-wrapper">
            <div class="search-container mb-4">
                <form method="GET" action="home.php#rekomendasi" class="position-relative">
                    <input type="text" name="keyword" class="form-control search-input" placeholder="Cari Buku...">
                    <button type="submit" class="search-btn"><i class="bi bi-search"></i></button>
                </form>
            </div>

            <div class="mb-4">
                <h3 class="fw-bold">Keranjang Belanja</h3>
                <p class="text-muted small">Centang buku yang ingin Anda beli, lalu lanjutkan ke checkout.</p>
            </div>

            <?php if (!$loggedIn): ?>
                <div class="card border-0 shadow-sm rounded-4 p-5 text-center bg-white">
                    <div class="mx-auto mb-3 d-flex align-items-center justify-content-center rounded-circle bg-primary-subtle text-primary" style="width:72px;height:72px">
                        <i class="bi bi-cart3 fs-2"></i>
                    </div>
                    <h5 class="fw-bold">Keranjang Belanja</h5>
                    <p class="text-muted mb-4">Login atau daftar terlebih dahulu untuk menggunakan keranjang.</p>
                    <div class="d-flex justify-content-center gap-2">
                        <a href="../login.php?redirect=cart" class="btn btn-primary rounded-pill px-4">Login</a>
                        <a href="../register.php" class="btn btn-outline-primary rounded-pill px-4">Daftar</a>
                    </div>
                </div>
            <?php else: ?>
                <!-- Form Checkout membungkus tabel agar item yang dicentang bisa dikirim -->
                <form action="checkout.php" method="POST" id="form-checkout">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white mb-4">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-primary">
                                    <tr>
                                        <th width="50" class="ps-4">
                                            <input type="checkbox" id="select-all" class="form-check-input" onclick="toggleSelectAll(this)">
                                        </th>
                                        <th width="80">Gambar</th>
                                        <th>Judul Buku</th>
                                        <th>Harga</th>
                                        <th width="160" class="text-center">Jumlah</th>
                                        <th>Subtotal</th>
                                        <th width="90" class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $total = 0;
                                    $has = false;
                                    while ($c = mysqli_fetch_assoc($cart)) {
                                        $has = true;
                                        $subtotal = $c['harga'] * $c['jumlah'];
                                        $total += $subtotal;
                                        $is_habis = ($c['stok'] <= 0 || $c['jumlah'] > $c['stok']);
                                    ?>
                                        <tr class="<?= $is_habis ? 'table-danger' : ''; ?>">
                                            <td class="ps-4">
                                                <!-- Checkbox per item (Disabled jika stok habis) -->
                                                <?php if (!$is_habis): ?>
                                                    <input type="checkbox" name="selected_items[]" value="<?=$c['id_cart'];?>" class="form-check-input item-checkbox" onchange="hitungTotal()">
                                                <?php else: ?>
                                                    <input type="checkbox" class="form-check-input" disabled title="Stok habis, tidak dapat dipilih">
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <img src="../assets/img/buku/<?=htmlspecialchars($c['gambar']);?>" width="55" height="70" class="rounded-3 shadow-sm" style="object-fit:cover" onerror="this.src='https://via.placeholder.com/55x70?text=No+Cover'">
                                            </td>
                                            <td class="fw-bold">
                                                <?=htmlspecialchars($c['judul']);?>
                                                <?php if ($is_habis): ?>
                                                    <br><span class="badge bg-danger text-white mt-1">Stok Habis / Tidak Mencukupi (Sisa: <?=$c['stok'];?>)</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>Rp <?=number_format($c['harga'], 0, ',', '.');?></td>
                                            
                                            <!-- Tombol Jumlah -->
                                            <td class="text-center">
                                                <?php if ($c['stok'] > 0): ?>
                                                    <div class="d-inline-flex align-items-center justify-content-center gap-2">
                                                        <button type="button" class="qty-btn minus" onclick="ubahJumlahAjax(<?=$c['id_cart'];?>, -1, <?=$c['stok'];?>)">-</button>
                                                        <input type="number" id="input-qty-<?=$c['id_cart'];?>" value="<?=$c['jumlah'];?>" min="1" max="<?=$c['stok'];?>" class="form-control form-control-sm text-center fw-bold" style="width: 55px;" readonly>
                                                        <button type="button" class="qty-btn plus" onclick="ubahJumlahAjax(<?=$c['id_cart'];?>, 1, <?=$c['stok'];?>)">+</button>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Stok 0</span>
                                                <?php endif; ?>
                                            </td>

                                            <td class="fw-bold text-success" id="subtotal-<?=$c['id_cart'];?>" data-harga="<?=$c['harga'];?>" data-subtotal="<?=$subtotal;?>">
                                                Rp <?=number_format($subtotal, 0, ',', '.');?>
                                            </td>
                                            <td class="text-center">
                                                <a href="hapus_cart.php?id=<?=$c['id_cart'];?>" class="btn btn-danger btn-sm rounded-3" onclick="return confirm('Hapus buku ini dari keranjang?')">
                                                    Hapus
                                                </a>
                                            </td>
                                        </tr>
                                    <?php } ?>

                                    <?php if ($has): ?>
                                        <tr>
                                            <td colspan="5" class="text-end fw-bold">Total Pilihan Checkout</td>
                                            <td colspan="2" class="fw-bold text-success fs-5" id="grand-total">Rp 0</td>
                                        </tr>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="7" class="text-center py-5 text-muted">Keranjang belanja Anda masih kosong.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <a href="../index.php" class="btn btn-outline-secondary rounded-pill px-4">Lanjut Belanja</a>
                        <?php if ($has): ?>
                            <button type="submit" name="btn_checkout" class="btn btn-success rounded-pill px-5 py-2 fw-bold" id="btn-checkout" disabled>
                                Checkout Pilihan
                            </button>
                        <?php endif; ?>
                    </div>
                </form>
            <?php endif; ?>
        </main>
    </div>

    <!-- Script JavaScript untuk Checkbox & Update Qty Realtime -->
    <script>
        // Mengubah nilai angka menjadi format mata uang Rupiah untuk ditampilkan kepada pengguna.
        function formatRupiah(angka) {
            return 'Rp ' + angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        }

        // Menghitung total harga berdasarkan item keranjang yang sedang dipilih.

        function hitungTotal() {
            let total = 0;
            let checkedCount = 0;
            const checkboxes = document.querySelectorAll('.item-checkbox');
            
            checkboxes.forEach(cb => {
                if (cb.checked) {
                    checkedCount++;
                    const row = cb.closest('tr');
                    const subtotalEl = row.querySelector('[id^="subtotal-"]');
                    total += parseInt(subtotalEl.getAttribute('data-subtotal'));
                }
            });

            document.getElementById('grand-total').textContent = formatRupiah(total);
            
            const btnCheckout = document.getElementById('btn-checkout');
            if (btnCheckout) {
                btnCheckout.disabled = (checkedCount === 0);
            }
        }

        // Memilih atau membatalkan pilihan seluruh item keranjang secara bersamaan.

        function toggleSelectAll(source) {
            const checkboxes = document.querySelectorAll('.item-checkbox');
            checkboxes.forEach(cb => {
                if (!cb.disabled) {
                    cb.checked = source.checked;
                }
            });
            hitungTotal();
        }

        // Fungsi mengubah jumlah via background request (Fetch API) tanpa reload total halaman
        // Memperbarui jumlah item keranjang melalui permintaan AJAX tanpa memuat ulang seluruh halaman.
        function ubahJumlahAjax(idCart, nilaiUbah, maxStok) {
            const inputField = document.getElementById('input-qty-' + idCart);
            let nilaiSekarang = parseInt(inputField.value);
            let nilaiBaru = nilaiSekarang + nilaiUbah;
            
            if (nilaiBaru < 1) nilaiBaru = 1;
            if (nilaiBaru > maxStok) {
                alert('Jumlah melebihi stok buku yang tersedia (' + maxStok + ')');
                nilaiBaru = maxStok;
            }
            
            if (nilaiBaru !== nilaiSekarang) {
                inputField.value = nilaiBaru;
                
                // Kirim data update ke file ini sendiri via AJAX
                const formData = new FormData();
                formData.append('update_jumlah', '1');
                formData.append('id_cart', idCart);
                formData.append('jumlah', nilaiBaru);

                fetch('cart.php', {
                    method: 'POST',
                    body: formData
                }).then(response => {
                    if (response.ok) {
                        // Perbarui subtotal pada baris terkait secara dinamis
                        const row = inputField.closest('tr');
                        const harga = parseInt(row.querySelector('[id^="subtotal-"]').getAttribute('data-harga'));
                        const subtotalBaru = harga * nilaiBaru;
                        
                        const subtotalEl = row.querySelector('[id^="subtotal-"]');
                        subtotalEl.setAttribute('data-subtotal', subtotalBaru);
                        subtotalEl.textContent = formatRupiah(subtotalBaru);
                        
                        hitungTotal();
                    }
                });
            }
        }

        // Jalankan hitung total saat halaman dimuat pertama kali
        document.addEventListener('DOMContentLoaded', () => {
            hitungTotal();
        });
    </script>
</body>
</html>