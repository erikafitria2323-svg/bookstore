<?php
/**
 * Memproses penambahan buku ke keranjang pelanggan atau menambah jumlah jika buku tersebut sudah ada.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

if (!isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit;
}

$id_user = $_SESSION['id_user'];
$id_buku = $_POST['id_buku'] ?? 0;
$redirect = $_POST['redirect'] ?? 'home';

if ($id_buku) {
    // Cek apakah buku sudah ada di keranjang user
    $cek = mysqli_query($conn, "SELECT * FROM cart WHERE id_user = '$id_user' AND id_buku = '$id_buku'");

    if (mysqli_num_rows($cek) > 0) {
        // Jika sudah ada, tambahkan jumlahnya (qty)
        mysqli_query($conn, "UPDATE cart SET jumlah = jumlah + 1 WHERE id_user = '$id_user' AND id_buku = '$id_buku'");
    } else {
        // Jika belum ada, masukkan data baru
        mysqli_query($conn, "INSERT INTO cart (id_user, id_buku, jumlah) VALUES ('$id_user', '$id_buku', 1)");
    }
}

// Redirect kembali sesuai asalnya
if ($redirect === 'detail') {
    header("Location: detail.php?id=" . $id_buku);
    exit;
} else {
    header("Location: cart.php");
    exit;
}