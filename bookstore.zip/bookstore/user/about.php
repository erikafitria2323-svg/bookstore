<?php
/**
 * Menampilkan halaman informasi mengenai Neo Bookstore, termasuk profil dan tujuan toko.
 */
session_start();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami - NEO BSTORE</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Custom Style -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

<div class="container py-5">

    <!-- Header Page -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold m-0"><i class="bi bi-info-circle me-2 text-primary"></i>Tentang Kami</h3>
            <p class="text-muted small m-0">Mengenal lebih dekat platform toko buku online NEO BSTORE</p>
        </div>
        <a href="../index.php" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
    </div>

    <!-- Main Card Content -->
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-4 p-md-5">
            
            <!-- Hero Section Inside Card -->
            <div class="row align-items-center mb-5">
                <div class="col-lg-8">
                    <span class="badge bg-primary-subtle text-primary fw-semibold mb-2 px-3 py-2 rounded-pill">
                        Toko Buku Online
                    </span>
                    <h2 class="fw-bold display-6 mb-3 text-primary">NEO BSTORE</h2>
                    <p class="lead text-secondary">
                        NEO BSTORE adalah platform penjualan buku yang menyediakan berbagai macam buku untuk memenuhi kebutuhan membaca dan belajar Anda.
                    </p>
                    <p class="text-muted">
                        Kami menyediakan berbagai kategori buku seperti <strong>Novel, Teknologi, Pendidikan, dan Agama</strong> dengan proses pemesanan yang mudah dan praktis.
                    </p>
                </div>
                <div class="col-lg-4 text-center d-none d-lg-block">
                    <i class="bi bi-journal-bookmark-fill text-primary opacity-25" style="font-size: 8rem;"></i>
                </div>
            </div>

            <hr class="my-4 text-muted opacity-25">

            <!-- Why Choose Us Section -->
            <h4 class="fw-bold text-center mb-4">Mengapa Memilih NEO BSTORE?</h4>

            <div class="row g-4 text-center">
                <!-- Feature 1 -->
                <div class="col-md-4">
                    <div class="p-4 rounded-3 bg-light h-100 border">
                        <div class="d-inline-flex align-items-center justify-content-center bg-primary text-white rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-book fs-3"></i>
                        </div>
                        <h5 class="fw-semibold">Banyak Pilihan</h5>
                        <p class="text-muted small mb-0">
                            Berbagai buku dari beberapa kategori tersedia untuk memenuhi kebutuhan membaca Anda.
                        </p>
                    </div>
                </div>

                <!-- Feature 2 -->
                <div class="col-md-4">
                    <div class="p-4 rounded-3 bg-light h-100 border">
                        <div class="d-inline-flex align-items-center justify-content-center bg-success text-white rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-cart-check fs-3"></i>
                        </div>
                        <h5 class="fw-semibold">Mudah Dipesan</h5>
                        <p class="text-muted small mb-0">
                            Pesan buku dengan mudah dan praktis melalui keranjang belanja.
                        </p>
                    </div>
                </div>

                <!-- Feature 3 -->
                <div class="col-md-4">
                    <div class="p-4 rounded-3 bg-light h-100 border">
                        <div class="d-inline-flex align-items-center justify-content-center bg-warning text-dark rounded-circle mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-truck fs-3"></i>
                        </div>
                        <h5 class="fw-semibold">Pembayaran COD</h5>
                        <p class="text-muted small mb-0">
                            Pembayaran dapat dilakukan dengan mudah saat buku diterima di tempat Anda.
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>