<?php
/**
 * Menampilkan informasi lengkap buku yang dipilih pelanggan berdasarkan ID buku.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

$id = $_GET['id'] ?? 0;

$query = mysqli_query($conn, "
    SELECT buku.*, kategori.nama_kategori
    FROM buku
    JOIN kategori ON buku.id_kategori = kategori.id_kategori
    WHERE id_buku='$id'
");

$buku = mysqli_fetch_assoc($query);

if (!$buku) {
    header("Location: ../index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Buku - NEO BSTORE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>

<body>

    <div class="container py-5">
        <div class="row">
            <div class="col-md-4">
                <img src="../assets/img/buku/<?= htmlspecialchars($buku['gambar']); ?>" class="img-fluid rounded shadow" onerror="this.src='https://via.placeholder.com/200x260?text=No+Cover'">
            </div>

            <div class="col-md-8">
                <h2><?= htmlspecialchars($buku['judul']); ?></h2>

                <p class="text-muted mb-2">
                    Penulis : <b><?= htmlspecialchars($buku['penulis']); ?></b>
                </p>

                <p class="mb-2">
                    Kategori :
                    <span class="badge bg-primary-subtle text-primary fw-semibold rounded-pill px-3 py-1">
                        <?= htmlspecialchars($buku['nama_kategori']); ?>
                    </span>
                </p>

                <!-- Informasi Stok -->
                <p class="mb-3">
                    Stok Tersedia : 
                    <?php if ($buku['stok'] > 0): ?>
                        <span class="badge bg-success-subtle text-success fw-semibold px-3 py-1"><?= $buku['stok']; ?> Pcs</span>
                    <?php else: ?>
                        <span class="badge bg-danger-subtle text-danger fw-semibold px-3 py-1">Habis</span>
                    <?php endif; ?>
                </p>

                <h3 class="text-success mb-3">
                    Rp <?= number_format($buku['harga'], 0, ",", "."); ?>
                </h3>

                <p>
                    <?= nl2br(htmlspecialchars($buku['deskripsi'])); ?>
                </p>

                <!-- Pengecekan Stok untuk Tombol Keranjang -->
                <?php if ($buku['stok'] > 0): ?>
                    <?php if (isset($_SESSION['id_user'])): ?>
                        <!-- Mengarah ke add_cart.php untuk memasukkan buku ke tabel keranjang -->
                        <form method="POST" action="add_cart.php" class="d-inline">
                            <input type="hidden" name="id_buku" value="<?= $buku['id_buku']; ?>">
                            <input type="hidden" name="redirect" value="detail">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-cart-plus me-1"></i> Tambah ke Keranjang
                            </button>
                        </form>
                    <?php else: ?>
                        <a href="../login.php?redirect=cart" class="btn btn-primary" onclick="return confirm('Anda harus login terlebih dahulu untuk menambahkan buku ke keranjang. Login sekarang?');">
                            <i class="bi bi-cart-plus me-1"></i> Tambah ke Keranjang
                        </a>
                    <?php endif; ?>
                <?php else: ?>
                    <!-- Tombol Disabled jika Stok Habis -->
                    <button type="button" class="btn btn-secondary" disabled>
                        <i class="bi bi-x-circle me-1"></i> Stok Habis
                    </button>
                <?php endif; ?>
                
                <br><br>
                <a href="../index.php" class="btn btn-outline-secondary">
                    Kembali
                </a>
            </div>
        </div>
    </div>

</body>

</html>