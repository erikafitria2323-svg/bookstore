<?php
/**
 * Menampilkan kategori buku beserta informasi atau jumlah buku pada setiap kategori.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

// Fungsi Pemetaan Ikon & Warna Kategori
// Menentukan ikon dan warna tampilan yang sesuai dengan nama kategori buku.
function getCategoryStyle($nama) {
    $nama_clean = strtolower(trim($nama));
    
    if (strpos($nama_clean, 'novel') !== false) {
        return ['icon' => 'bi-book', 'bg' => '#FFEAD2', 'color' => '#E07A5F'];
    } elseif (strpos($nama_clean, 'komik') !== false) {
        return ['icon' => 'bi-chat-left-text', 'bg' => '#E0F4FE', 'color' => '#0284C7'];
    } elseif (strpos($nama_clean, 'pendidikan') !== false) {
        return ['icon' => 'bi-compass', 'bg' => '#DCFCE7', 'color' => '#16A34A'];
    } elseif (strpos($nama_clean, 'anak') !== false) {
        return ['icon' => 'bi-emoji-smile', 'bg' => '#FEF08A', 'color' => '#CA8A04'];
    } elseif (strpos($nama_clean, 'bisnis') !== false) {
        return ['icon' => 'bi-briefcase', 'bg' => '#F3E8FF', 'color' => '#9333EA'];
    } elseif (strpos($nama_clean, 'pengembangan diri') !== false) {
        return ['icon' => 'bi-tree', 'bg' => '#FDF4AF', 'color' => '#CA8A04'];
    } elseif (strpos($nama_clean, 'sejarah') !== false) {
        return ['icon' => 'bi-folder', 'bg' => '#E5E7EB', 'color' => '#4B5563'];
    } elseif (strpos($nama_clean, 'agama') !== false) {
        return ['icon' => 'bi-moon-stars', 'bg' => '#E2E8F0', 'color' => '#334155'];
    } elseif (strpos($nama_clean, 'teknologi') !== false) {
        return ['icon' => 'bi-cpu', 'bg' => '#E2E8F0', 'color' => '#334155'];
    }

    return ['icon' => 'bi-bookmark', 'bg' => '#F1F5F9', 'color' => '#64748B'];
}

// Query mengambil seluruh daftar kategori + jumlah bukunya secara dinamis
$query_kategori = mysqli_query($conn, "
    SELECT kategori.*, COUNT(buku.id_buku) AS jumlah_buku
    FROM kategori
    LEFT JOIN buku ON kategori.id_kategori = buku.id_kategori
    GROUP BY kategori.id_kategori
    ORDER BY kategori.id_kategori ASC
");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategori Buku - NEO BSTORE</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom Style -->
    <link rel="stylesheet" href="../assets/css/style.css">

    <style>
        .category-page-card {
            background-color: #FFFFFF !important;
            border: 1px solid #E2E8F0 !important;
            border-radius: 20px !important;
            padding: 28px 20px !important;
            transition: all 0.25s ease !important;
            text-align: center !important;
            box-shadow: 0 2px 8px rgba(0,0,0,0.02) !important;
        }

        .category-page-card:hover {
            transform: translateY(-5px) !important;
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.08) !important;
        }

        .category-page-icon {
            width: 60px !important;
            height: 60px !important;
            border-radius: 18px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            font-size: 26px !important;
            margin: 0 auto 16px auto !important;
        }

        .btn-lihat-buku {
            border: 1.5px solid #3B82F6 !important;
            color: #3B82F6 !important;
            background-color: #FFFFFF !important;
            font-size: 13px !important;
            padding: 8px 16px !important;
            font-weight: 600 !important;
            transition: all 0.2s ease !important;
            text-decoration: none !important;
            display: block !important;
        }

        .btn-lihat-buku:hover {
            background-color: #3B82F6 !important;
            color: #FFFFFF !important;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.25) !important;
        }
    </style>
</head>

<body>

    <div class="d-flex min-vh-100">

        <!-- Sidebar Left -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
            </div>

            <nav class="sidebar-nav">
                <a href="../index.php">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Beranda</span>
                </a>
                <a href="kategori.php" class="active">
                    <i class="bi bi-bar-chart-steps"></i>
                    <span>Kategori</span>
                </a>
                <a href="cart.php">
                    <i class="bi bi-cart3"></i>
                    <span>Keranjang</span>
                </a>
                <a href="pesanan.php">
                    <i class="bi bi-box-seam"></i>
                    <span>Pesanan Saya</span>
                </a>
                <a href="about.php">
                    <i class="bi bi-info-circle"></i>
                    <span>Tentang Kami</span>
                </a>
                <a href="contact.php">
                    <i class="bi bi-chat-dots"></i>
                    <span>Hubungi Admin</span>
                </a>
                <?php if (isset($_SESSION['id_user'])): ?>
                    <a href="../logout.php" class="text-danger mt-auto">
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Logout</span>
                    </a>
                <?php else: ?>
                    <a href="../login.php" class="text-primary mt-auto">
                        <i class="bi bi-box-arrow-in-right"></i>
                        <span>Login / Daftar</span>
                    </a>
                <?php endif; ?>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper">


            <!-- Page Header -->
            <div class="mb-4">
                <h3 class="fw-bold text-dark mb-1">Kategori Buku</h3>
                <p class="text-muted small mb-3">Temukan buku favoritmu berdasarkan kategori</p>
                <?php if (!isset($_SESSION['id_user'])): ?>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="../index.php#rekomendasi" class="btn btn-primary rounded-pill px-4">
                            <i class="bi bi-bag-check me-1"></i> Belanja Sekarang
                        </a>
                        <a href="../login.php" class="btn btn-outline-primary rounded-pill px-4">
                            Login / Daftar
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Grid Kategori -->
            <div class="row g-4">
                <?php while ($kat = mysqli_fetch_assoc($query_kategori)) { 
                    $style = getCategoryStyle($kat['nama_kategori']);
                ?>
                    <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                        <div class="category-page-card">
                            <div class="category-page-icon" style="background-color: <?= $style['bg']; ?>; color: <?= $style['color']; ?>;">
                                <i class="bi <?= $style['icon']; ?>"></i>
                            </div>
                            <h6 class="fw-bold mb-1 text-dark fs-6"><?= htmlspecialchars($kat['nama_kategori']); ?></h6>
                            <span class="text-muted small d-block mb-4"><?= $kat['jumlah_buku']; ?> Buku</span>
                            <a href="../index.php?kategori=<?= $kat['id_kategori']; ?>#rekomendasi" class="btn btn-lihat-buku rounded-pill w-100">
                                Lihat Buku
                            </a>
                        </div>
                    </div>
                <?php } ?>
            </div>

        </main>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>