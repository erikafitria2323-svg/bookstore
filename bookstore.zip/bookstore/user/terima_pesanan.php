<?php
/**
 * Memproses konfirmasi penerimaan pesanan oleh user (mengubah status menjadi 'Selesai').
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

// Pastikan user sudah login
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id_pesanan = $_GET['id'];
    $id_user = $_SESSION['id_user'];

    // Pastikan pesanan tersebut benar-benar milik user yang sedang login dan statusnya 'Dikirim'
    $query = mysqli_query($conn, "SELECT * FROM pesanan WHERE id_pesanan='$id_pesanan' AND id_user='$id_user'");
    $pesanan = mysqli_fetch_assoc($query);

    if ($pesanan && $pesanan['status'] === 'Dikirim') {
        // Update status pesanan menjadi Selesai
        mysqli_query($conn, "UPDATE pesanan SET status='Selesai' WHERE id_pesanan='$id_pesanan'");
    }
}

// Redirect kembali ke halaman pesanan saya
header("Location: pesanan.php");
exit;
?>