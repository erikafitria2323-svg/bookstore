<?php
/**
 * Menampilkan dan mengelola daftar kategori buku yang digunakan untuk mengelompokkan katalog.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: ../login.php");
    exit;
}

if (isset($_POST['simpan'])) {
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);

    if (!empty($kategori)) {
        mysqli_query($conn, "
            INSERT INTO kategori(nama_kategori)
            VALUES('$kategori')
        ");
    }

    header("Location: kategori.php");
    exit;
}

$data = mysqli_query($conn, "
    SELECT *
    FROM kategori
    ORDER BY id_kategori DESC
");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kategori - Admin NEO BSTORE</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="d-flex min-vh-100 admin-layout">

        <!-- Sidebar Left (Sama Persis Seperti Halaman User) -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
                <small class="badge bg-danger-subtle text-danger fw-semibold px-2 py-1 mt-1">ADMIN PANEL</small>
            </div>

            <nav class="sidebar-nav">
                <a href="dashboard.php">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Dashboard</span>
                </a>
                <a href="kategori.php" class="active">
                    <i class="bi bi-bar-chart-steps"></i>
                    <span>Kategori</span>
                </a>
                <a href="buku.php">
                    <i class="bi bi-book"></i>
                    <span>Buku</span>
                </a>
                <a href="user.php">
                    <i class="bi bi-people"></i>
                    <span>User</span>
                </a>
                <a href="pesanan.php">
                    <i class="bi bi-box-seam"></i>
                    <span>Pesanan</span>
                </a>
                <a href="pesan.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'pesan.php') ? 'active' : '' ?>">
                    <i class="bi bi-chat-left-text-fill"></i>
                    <span>Pesan Masuk</span>
                </a>
                <a href="tampilan_user.php">
                    <i class="bi bi-shop"></i>
                    <span>Tampilan User</span>
                </a>
                <a href="../logout.php" class="text-danger mt-auto">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Logout</span>
                </a>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper">

            <!-- Page Header -->
            <div class="mb-4">
                <h3 class="fw-bold text-dark mb-1">Data Kategori</h3>
                <p class="text-muted small mb-0">Kelola kategori buku yang tersedia di toko online</p>
            </div>

            <!-- Form Tambah Kategori -->
            <div class="card border-0 shadow-sm rounded-4 p-3 mb-4 bg-white">
                <form method="POST">
                    <div class="row g-2 align-items-center">
                        <div class="col-md-9">
                            <input type="text" name="kategori" class="form-control rounded-5" placeholder="Nama Kategori..." required>
                        </div>
                        <div class="col-md-3">
                            <button name="simpan" class="btn btn-lihat-buku rounded-pill px-4">
                                <i class="bi bi-plus-lg me-1"></i> Tambah Kategori
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Tabel Data Kategori -->
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-primary">
                            <tr>
                                <th width="80" class="ps-4">No</th>
                                <th>Nama Kategori</th>
                                <th width="180" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            while ($k = mysqli_fetch_assoc($data)) {
                            ?>
                                <tr>
                                    <td class="ps-4 fw-semibold"><?= $no++; ?></td>
                                    <td><?= htmlspecialchars($k['nama_kategori']); ?></td>
                                    <td class="text-center">
                                        <a href="edit_kategori.php?id=<?= $k['id_kategori']; ?>" class="btn btn-warning btn-sm rounded-3 me-1">
                                            <i class="bi bi-pencil-square"></i> Edit
                                        </a>
                                        <a href="hapus_kategori.php?id=<?= $k['id_kategori']; ?>" class="btn btn-danger btn-sm rounded-3" onclick="return confirm('Hapus kategori ini?')">
                                            <i class="bi bi-trash"></i> Hapus
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>

    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>