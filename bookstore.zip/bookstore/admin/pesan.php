<?php
/**
 * Menampilkan pesan dari pelanggan serta memproses tindakan admin seperti menghapus, menandai telah dibaca, dan membalas pesan.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

// Logika Hapus Pesan
if (isset($_GET['action']) && $_GET['action'] == 'hapus') {
    $id_pesan = intval($_GET['id']);
    mysqli_query($conn, "DELETE FROM pesan WHERE id_pesan = '$id_pesan'");
    $_SESSION['info'] = ['type' => 'success', 'message' => 'Pesan berhasil dihapus.'];
    header("Location: pesan.php");
    exit;
}

// Logika Tandai Sudah Dibaca
if (isset($_GET['action']) && $_GET['action'] == 'baca') {
    $id_pesan = intval($_GET['id']);
    mysqli_query($conn, "UPDATE pesan SET status = 'sudah_dibaca' WHERE id_pesan = '$id_pesan'");
    header("Location: pesan.php");
    exit;
}

// Logika Simpan Balasan Admin
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kirim_balasan'])) {
    $id_pesan = intval($_POST['id_pesan']);
    $balasan  = trim($_POST['balasan']);

    if (!empty($balasan)) {
        $stmt = mysqli_prepare($conn, "UPDATE pesan SET balasan = ?, status = 'sudah_dibaca' WHERE id_pesan = ?");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "si", $balasan, $id_pesan);
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['info'] = ['type' => 'success', 'message' => 'Balasan berhasil dikirim ke user!'];
            }
            mysqli_stmt_close($stmt);
        }
    }
    header("Location: pesan.php");
    exit;
}

// Query JOIN mengambil data pesan dan user
$sql = "SELECT pesan.*, user.* 
        FROM pesan 
        LEFT JOIN user ON pesan.id_user = user.id_user 
        ORDER BY pesan.tanggal DESC";
$query = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesan Masuk - Admin NEO BSTORE</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom Style -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

    <div class="d-flex min-vh-100 admin-layout">

        <!-- Sidebar Left Admin -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
                <span class="badge bg-danger-subtle text-danger fw-bold px-2 py-1 rounded small">ADMIN PANEL</span>
            </div>

            <nav class="sidebar-nav">
                <a href="dashboard.php"><i class="bi bi-house-door"></i><span>Dashboard</span></a>
                <a href="kategori.php"><i class="bi bi-bar-chart-steps"></i><span>Kategori</span></a>
                <a href="buku.php"><i class="bi bi-book"></i><span>Buku</span></a>
                <a href="user.php"><i class="bi bi-people"></i><span>User</span></a>
                <a href="pesanan.php"><i class="bi bi-box-seam"></i><span>Pesanan</span></a>
                <a href="pesan.php" class="active"><i class="bi bi-chat-left-text-fill"></i><span>Pesan Masuk</span></a>
                <a href="tampilan_user.php">
                    <i class="bi bi-shop"></i>
                    <span>Tampilan User</span>
                </a>
                <a href="../logout.php" class="text-danger mt-auto"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper p-4 w-100">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Pesan Masuk</h3>
                    <p class="text-muted mb-0">Kelola dan tanggapi pertanyaan atau keluhan dari pelanggan.</p>
                </div>
            </div>

            <!-- Pesan Notifikasi Alert -->
            <?php if (isset($_SESSION['info'])): ?>
                <div class="alert alert-<?= $_SESSION['info']['type']; ?> alert-dismissible fade show shadow-sm mb-4" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i>
                    <?= $_SESSION['info']['message']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['info']); ?>
            <?php endif; ?>

            <!-- Card Container -->
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th width="20%">Pengirim</th>
                                    <th width="22%">Email</th>
                                    <th>Isi Pesan</th>
                                    <th width="15%">Tanggal</th>
                                    <th width="12%">Status</th>
                                    <th width="12%" class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($query && mysqli_num_rows($query) > 0): ?>
                                    <?php $no = 1; while ($row = mysqli_fetch_assoc($query)): 
                                        $nama_pengirim = $row['nama'] ?? $row['nama_lengkap'] ?? $row['username'] ?? $row['nama_user'] ?? ('User #' . $row['id_user']);
                                        $email_pengirim = $row['email'] ?? $row['email_user'] ?? '';
                                        $sudah_dibalas = !empty($row['balasan']);
                                    ?>
                                        <tr class="<?= ($row['status'] == 'belum_dibaca') ? 'fw-bold table-warning' : '' ?>">
                                            <td><?= $no++; ?></td>
                                            <td><?= htmlspecialchars($nama_pengirim); ?></td>
                                            <td>
                                                <?php if (!empty($email_pengirim)): ?>
                                                    <a href="mailto:<?= $email_pengirim; ?>" class="text-decoration-none"><?= htmlspecialchars($email_pengirim); ?></a>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="text-truncate" style="max-width: 300px;">
                                                    <?= htmlspecialchars($row['pesan']); ?>
                                                </div>
                                            </td>
                                            <td class="small text-muted"><?= date('d M Y, H:i', strtotime($row['tanggal'])); ?></td>
                                            <td>
                                                <?php if ($sudah_dibalas): ?>
                                                    <span class="badge bg-success rounded-pill px-2 py-1"><i class="bi bi-check2-all me-1"></i>Sudah Dibalas</span>
                                                <?php elseif ($row['status'] == 'belum_dibaca'): ?>
                                                    <span class="badge bg-warning text-dark rounded-pill px-2 py-1">Baru</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary rounded-pill px-2 py-1">Dibaca</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <button class="btn btn-sm btn-info text-white me-1" data-bs-toggle="modal" data-bs-target="#modalDetail<?= $row['id_pesan']; ?>" title="Lihat & Balas">
                                                    <i class="bi bi-reply-fill"></i>
                                                </button>
                                                <a href="pesan.php?action=hapus&id=<?= $row['id_pesan']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus pesan ini?')" title="Hapus">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>

                                        <!-- Modal Detail & Form Balas Pesan -->
                                        <div class="modal fade" id="modalDetail<?= $row['id_pesan']; ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                                <div class="modal-content border-0 shadow">
                                                    <div class="modal-header bg-primary text-white border-0">
                                                        <h5 class="modal-title fs-6 fw-bold"><i class="bi bi-envelope-open me-2"></i> Detail Pesan & Balasan Admin</h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body p-4">
                                                        <!-- Info Pengirim -->
                                                        <div class="mb-3">
                                                            <small class="text-muted d-block">Dari Pengguna:</small>
                                                            <strong class="fs-6 text-dark"><?= htmlspecialchars($nama_pengirim); ?></strong>
                                                            <?php if (!empty($email_pengirim)): ?>
                                                                <span class="text-muted">&lt;<?= htmlspecialchars($email_pengirim); ?>&gt;</span>
                                                            <?php endif; ?>
                                                        </div>

                                                        <!-- Isi Pesan User -->
                                                        <div class="mb-4">
                                                            <small class="text-muted d-block mb-1">Isi Pesan Pelanggan:</small>
                                                            <div class="p-3 bg-light rounded border text-break">
                                                                <?= nl2br(htmlspecialchars($row['pesan'])); ?>
                                                            </div>
                                                            <small class="text-muted d-block text-end mt-1"><?= date('d F Y - H:i', strtotime($row['tanggal'])); ?> WIB</small>
                                                        </div>

                                                        <hr class="my-4">

                                                        <!-- Form Input Balasan Admin -->
                                                        <form action="" method="POST">
                                                            <input type="hidden" name="id_pesan" value="<?= $row['id_pesan']; ?>">
                                                            
                                                            <div class="mb-3">
                                                                <label class="form-label fw-bold text-dark"><i class="bi bi-reply-fill text-primary me-1"></i>Tulis Balasan Admin:</label>
                                                                <textarea name="balasan" class="form-control" rows="4" placeholder="Tuliskan balasan/solusi untuk pelanggan di sini..." required><?= htmlspecialchars($row['balasan'] ?? ''); ?></textarea>
                                                            </div>

                                                            <div class="d-flex justify-content-between align-items-center">
                                                                <?php if ($row['status'] == 'belum_dibaca'): ?>
                                                                    <a href="pesan.php?action=baca&id=<?= $row['id_pesan']; ?>" class="btn btn-sm btn-outline-secondary rounded-pill">
                                                                        Tandai Dibaca Tanpa Balas
                                                                    </a>
                                                                <?php else: ?>
                                                                    <span></span>
                                                                <?php endif; ?>

                                                                <button type="submit" name="kirim_balasan" class="btn btn-primary rounded-pill px-4">
                                                                    <i class="bi bi-send-fill me-1"></i> Kirim Balasan
                                                                </button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-5 text-muted">
                                            <i class="bi bi-inbox display-5 d-block mb-2"></i>
                                            Belum ada pesan masuk dari pengguna.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>