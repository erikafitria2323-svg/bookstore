<?php
/**
 * Menampilkan formulir dan memproses penyimpanan data buku baru, termasuk informasi buku dan berkas gambar jika tersedia.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: login.php");
    exit;
}

$kategori = mysqli_query($conn, "SELECT * FROM kategori");

if (isset($_POST['simpan'])) {
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $id_kategori = $_POST['id_kategori'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok']; // Tangkap input stok
    $deskripsi = $_POST['deskripsi'];

    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];

    move_uploaded_file($tmp, "../assets/img/buku/" . $gambar);

    mysqli_query($conn, "
        INSERT INTO buku(id_kategori, judul, penulis, harga, stok, gambar, deskripsi)
        VALUES('$id_kategori', '$judul', '$penulis', '$harga', '$stok', '$gambar', '$deskripsi')
    ");

    header("Location: buku.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku - Admin NEO BSTORE</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="d-flex min-vh-100 admin-layout">

        <!-- Sidebar Left -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
                <small class="badge bg-danger-subtle text-danger fw-semibold px-2 py-1 mt-1">ADMIN PANEL</small>
            </div>

            <nav class="sidebar-nav">
                <a href="dashboard.php">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Dashboard</span>
                </a>
                <a href="kategori.php">
                    <i class="bi bi-bar-chart-steps"></i>
                    <span>Kategori</span>
                </a>
                <a href="buku.php" class="active">
                    <i class="bi bi-book"></i>
                    <span>Buku</span>
                </a>
                <a href="user.php">
                    <i class="bi bi-people"></i>
                    <span>User</span>
                </a>
                <a href="pesanan.php">
                    <i class="bi bi-box-seam"></i>
                    <span>Pesanan</span>
                </a>
                <a href="pesan.php">
                    <i class="bi bi-chat-left-text-fill"></i>
                    <span>Pesan Masuk</span>
                </a>
                <a href="tampilan_user.php">
                    <i class="bi bi-shop"></i>
                    <span>Tampilan User</span>
                </a>
                <a href="../logout.php" class="text-danger mt-auto">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Logout</span>
                </a>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper">

            <!-- Page Header -->
            <div class="mb-4">
                <h3 class="fw-bold text-dark mb-1">Tambah Buku Baru</h3>
                <p class="text-muted small mb-0">Isi form di bawah untuk menambahkan katalog buku baru</p>
            </div>

            <!-- Form Card -->
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Judul Buku</label>
                        <input type="text" name="judul" class="form-control rounded-3" placeholder="Masukkan judul buku..." required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Penulis</label>
                        <input type="text" name="penulis" class="form-control rounded-3" placeholder="Masukkan nama penulis..." required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Kategori</label>
                        <select name="id_kategori" class="form-select rounded-3" required>
                            <option value="">Pilih Kategori</option>
                            <?php while ($k = mysqli_fetch_assoc($kategori)) { ?>
                                <option value="<?= $k['id_kategori']; ?>">
                                    <?= htmlspecialchars($k['nama_kategori']); ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Harga (Rp)</label>
                        <input type="number" name="harga" class="form-control rounded-3" placeholder="Contoh: 50000" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Stok Buku</label>
                        <input type="number" name="stok" class="form-control rounded-3" placeholder="Contoh: 10" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control rounded-3" rows="4" placeholder="Tuliskan sinopsis atau deskripsi buku..." required></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold">Cover Buku</label>
                        <input type="file" name="gambar" class="form-control rounded-3" required>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" name="simpan" class="btn btn-primary rounded-pill px-4">
                            <i class="bi bi-save me-1"></i> Simpan Buku
                        </button>
                        <a href="buku.php" class="btn btn-light rounded-pill px-4">
                            Kembali
                        </a>
                    </div>
                </form>
            </div>

        </main>

    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>