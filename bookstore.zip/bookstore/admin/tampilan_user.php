<?php
/**
 * Menyediakan pratinjau tampilan website dari sisi pelanggan melalui area admin.
 */
session_start();
include __DIR__ . '/../config/koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampilan User - Admin NEO BSTORE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <div class="d-flex min-vh-100 admin-layout">

        <!-- Sidebar Admin -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
                <small class="badge bg-danger-subtle text-danger fw-semibold px-2 py-1 mt-1">
                    ADMIN PANEL
                </small>
            </div>

            <nav class="sidebar-nav">
                <a href="dashboard.php">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Dashboard</span>
                </a>
                <a href="kategori.php">
                    <i class="bi bi-bar-chart-steps"></i>
                    <span>Kategori</span>
                </a>
                <a href="buku.php">
                    <i class="bi bi-book"></i>
                    <span>Buku</span>
                </a>
                <a href="user.php">
                    <i class="bi bi-people"></i>
                    <span>User</span>
                </a>
                <a href="pesanan.php">
                    <i class="bi bi-box-seam"></i>
                    <span>Pesanan</span>
                </a>
                <a href="pesan.php">
                    <i class="bi bi-chat-left-text-fill"></i>
                    <span>Pesan Masuk</span>
                </a>
                <a href="tampilan_user.php" class="active">
                    <i class="bi bi-shop"></i>
                    <span>Tampilan User</span>
                </a>
                <a href="../logout.php" class="text-danger mt-auto">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Logout</span>
                </a>
            </nav>
        </aside>

        <!-- Konten -->
        <main class="content-wrapper">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h3 class="fw-bold mb-1">Tampilan User</h3>
                    <p class="text-muted small mb-0">
                        Pratinjau toko tanpa meninggalkan panel admin.
                    </p>
                </div>

                <a href="dashboard.php" class="btn btn-outline-secondary rounded-pill px-4">
                    <i class="bi bi-arrow-left me-1"></i> Kembali
                </a>
            </div>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                <iframe
                    id="previewFrame"
                    class="preview-page"
                    src="../index.php"
                    title="Pratinjau halaman utama NEO BSTORE"
                ></iframe>
            </div>
        </main>
    </div>
    <script>
        // Terapkan mode pratinjau (sidebar ringkas) setiap kali halaman di dalam iframe dimuat
        document.getElementById('previewFrame').addEventListener('load', function () {
            try {
                var doc = this.contentDocument;
                doc.documentElement.classList.add('in-preview');
                // Sembunyikan Logout / Login agar admin tidak ter-logout dari pratinjau
                doc.querySelectorAll('a[href*="logout.php"], a[href*="login.php"]').forEach(function (a) {
                    if (a.closest('.sidebar-nav')) a.style.display = 'none';
                });
            } catch (e) {}
        });
    </script>
</body>
</html>
