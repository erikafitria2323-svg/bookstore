<?php
/**
 * Menampilkan data akun pelanggan yang terdaftar dan informasi terkait pengelolaan pengguna.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: login.php");
    exit;
}

$user = mysqli_query($conn, "
    SELECT *
    FROM user
    ORDER BY id_user DESC
");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data User - Admin NEO BSTORE</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="d-flex min-vh-100 admin-layout">

        <!-- Sidebar Left -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
                <small class="badge bg-danger-subtle text-danger fw-semibold px-2 py-1 mt-1">ADMIN PANEL</small>
            </div>

            <nav class="sidebar-nav">
                <a href="dashboard.php">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Dashboard</span>
                </a>
                <a href="kategori.php">
                    <i class="bi bi-bar-chart-steps"></i>
                    <span>Kategori</span>
                </a>
                <a href="buku.php">
                    <i class="bi bi-book"></i>
                    <span>Buku</span>
                </a>
                <a href="user.php" class="active">
                    <i class="bi bi-people"></i>
                    <span>User</span>
                </a>
                <a href="pesanan.php">
                    <i class="bi bi-box-seam"></i>
                    <span>Pesanan</span>
                </a>
                <a href="pesan.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'pesan.php') ? 'active' : '' ?>">
                    <i class="bi bi-chat-left-text-fill"></i>
                    <span>Pesan Masuk</span>
                </a>
                <a href="tampilan_user.php">
                    <i class="bi bi-shop"></i>
                    <span>Tampilan User</span>
                </a>
                <a href="../logout.php" class="text-danger mt-auto">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Logout</span>
                </a>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper">

            <!-- Page Header -->
            <div class="mb-4">
                <h3 class="fw-bold text-dark mb-1">Data User</h3>
                <p class="text-muted small mb-0">Daftar akun admin dan pelanggan terdaftar</p>
            </div>

            <!-- Tabel Data User -->
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-primary">
                            <tr>
                                <th width="60" class="ps-4">No</th>
                                <th>Nama Lengkap</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th width="120" class="text-center">Role</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            while ($u = mysqli_fetch_assoc($user)) {
                            ?>
                                <tr>
                                    <td class="ps-4 fw-semibold"><?= $no++; ?></td>
                                    <td class="fw-bold text-dark"><?= htmlspecialchars($u['nama']); ?></td>
                                    <td><code><?= htmlspecialchars($u['username']); ?></code></td>
                                    <td><?= htmlspecialchars($u['email']); ?></td>
                                    <td class="text-center">
                                        <?php if ($u['role'] == "admin") { ?>
                                            <span class="badge bg-danger-subtle text-danger fw-semibold rounded-pill px-3 py-1">Admin</span>
                                        <?php } else { ?>
                                            <span class="badge bg-success-subtle text-success fw-semibold rounded-pill px-3 py-1">User</span>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>

    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>