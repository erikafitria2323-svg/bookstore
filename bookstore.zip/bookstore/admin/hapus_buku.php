<?php
/**
 * Memproses penghapusan data buku berdasarkan ID setelah memastikan permintaan berasal dari admin.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'];

mysqli_query($conn, "
    DELETE FROM buku
    WHERE id_buku='$id'
");

header("Location:buku.php");
exit;